const MOVIES=[
{id:1,title:'Starlight',genre:'Sci-Fi / Adventure',language:'English',rating:8.7,duration:'2h 28m',cls:'blue',description:'A spectacular journey across distant worlds.'},
{id:2,title:'Rang De',genre:'Romance / Drama',language:'Telugu',rating:8.2,duration:'2h 15m',cls:'',description:'A story of love, friendship and family.'},
{id:3,title:'Shadow Mission',genre:'Action / Thriller',language:'Hindi',rating:8.5,duration:'2h 20m',cls:'green',description:'An agent races against time to stop a hidden threat.'},
{id:4,title:'Golden Hour',genre:'Drama',language:'English',rating:7.9,duration:'2h 05m',cls:'gold',description:'A family finds hope during a difficult year.'},
{id:5,title:'City Beats',genre:'Musical / Comedy',language:'Tamil',rating:8.0,duration:'2h 10m',cls:'blue',description:'Music, friendship and one unforgettable night.'},
{id:6,title:'The Last Code',genre:'Tech / Thriller',language:'English',rating:8.8,duration:'2h 32m',cls:'green',description:'A developer discovers a secret hidden in an AI system.'}
];
const EVENTS=[
{name:'Live Music Night',type:'Music',place:'Grand Arena',price:499},
{name:'Stand-up Comedy',type:'Comedy',place:'City Auditorium',price:399},
{name:'Tech Workshop',type:'Workshop',place:'Innovation Hub',price:299}
];